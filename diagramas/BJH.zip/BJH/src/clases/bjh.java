package clases;
import ventanas.login;
public class bjh {
	public static void main(String [] args) {
		login start = new login();
		start.excute();
	}
}