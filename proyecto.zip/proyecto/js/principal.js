
/*-- Quitamos el boton de intro para que no se envie el formulario por error --*/
window.addEventListener("keypress", function(event){
    if (event.keyCode == 13){
        event.preventDefault();
    }
}, false);

formulario.email.focus();

function siguiente(e) {
    var correo, pass, r_pass, expresion;
    correo = formulario.email.value;
    pass = formulario.pass.value;
    r_pass = formulario.repeatpass.value;
    expresion = /\w+@+\w+\.+[a-z]/;
    /* -- Campos vacios -- */
    if (correo == "" && pass == "" && r_pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        document.getElementById("repeatpass").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (pass == "" && r_pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "0";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        document.getElementById("repeatpass").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (correo == "" && r_pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "0";
        document.getElementById("repeatpass").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (correo == "" && pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        document.getElementById("repeatpass").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (correo == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "0";
        document.getElementById("repeatpass").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "0";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        document.getElementById("repeatpass").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (r_pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("email").style.border = "0";
        document.getElementById("pass").style.border = "0";
        document.getElementById("repeatpass").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }

    /* -- Verificaciones -- */
        /* -- Comprueba email -- */
    if (correo.length > 50) {
        document.getElementById("errors").innerHTML = "Tu correo supero mi visión de 'nadie hará esto', Congratulations <br>Bueno debe de ser menor que 50 caracteres #CreateUnoNuevo."
        document.getElementById("email").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "0";
        document.getElementById("repeatpass").style.border = "0";
        formulario.email.value = "";
        e.preventDefault();
        return 0;
    }
    if (!expresion.test(correo)) {
        document.getElementById("errors").innerHTML = "Tu correo no es válido, por favor compruebalo."
        document.getElementById("email").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "0";
        document.getElementById("repeatpass").style.border = "0";
        formulario.email.value = "";
        e.preventDefault();
        return 0;
    }
        /* -- Comprueba password -- */
    if (pass.length > 50) {
        document.getElementById("errors").innerHTML = "Tu contraseña excede todo rango de seguridad, seguro es perfecto. <br>Bueno debe de ser menor que 50 caracteres, nadie te va a quitar nada aqui."
        document.getElementById("email").style.border = "0";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        document.getElementById("repeatpass").style.border = "0";
        formulario.password.value = "";
        e.preventDefault();
        return 0;
    }
    if (pass != r_pass) {
        document.getElementById("errors").innerHTML = "Las contraseñas deben ser totalmente identicas.";
        document.getElementById("email").style.border = "0";
        document.getElementById("pass").style.border = "0";
        document.getElementById("repeatpass").style.border = "1px double var(--rojo-error)";
        formulario.pass.focus();
        formulario.pass.value = "";
        formulario.repeatpass.value = "";
        e.preventDefault();
        return 0;
    }
    document.getElementById("registro").style.display = "none";
    document.getElementById("reg1").style.display = "none";
    document.getElementById("reg2").style.display = "none";
    document.getElementById("complete").style.display = "flex";
    document.getElementById("comp1").style.display = "block";
    document.getElementById("errors").innerHTML = "";

}

function showPassword(){
    var password = document.getElementById("pass");
    var repeatpass = document.getElementById("repeatpass");
    if (password.type == "password" && repeatpass.type == "password") {
        document.getElementById("mostrar").style.color = "var(--verde-correcto)";
        password.type = "text";
        repeatpass.type = "text";
    } else {
        document.getElementById("mostrar").style.color = "var(--gris-luminoso)";
        password.type = "password";
        repeatpass.type = "password";
    }
}

function registrarse(e) {
    var dni, nombre, apellidos, direccion, username;
    dni = formulario.dni.value;
    nombre = formulario.nombre.value;
    apellidos = formulario.apellidos.value;
    direccion = formulario.direccion.value;
    username = formulario.usuario.value;
    expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
    /* -- Campos vacios -- */
    if (dni == "" && nombre == "" && apellidos == "" && direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (nombre == "" && apellidos == "" && direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (apellidos == "" && direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (direccion == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (apellidos == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (nombre == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (dni == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }

    /* -- Verificaciones -- */
        /* -- DNI -- */
    if (expresion_regular_dni.test(dni) == true) {
      numero = dni.substr(0 , dni.length - 1);
      letr = dni.substr(dni.length - 1, 1);
      numero = numero % 23;
      letra = 'TRWAGMYFPDXBNJZSQVHLCKET';
      letra = letra.substring(numero, numero + 1);
      if (letra != letr.toUpperCase()) {
        document.getElementById("errors").innerHTML = "La letra del DNI es incorrecta.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
     }
    } else {
        document.getElementById("errors").innerHTML = "Formato del DNI erróneo.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }

}

function sololtr(isEvento) {
    var evento = isEvento || window.event;
    var regex = new RegExp("^[a-zA-Z ]+$");
    var key = String.fromCharCode(!evento.charCode ? evento.which : evento.charCode);
    
    if (!regex.test(key)) {
      evento.preventDefault;
      return false;
    }
}