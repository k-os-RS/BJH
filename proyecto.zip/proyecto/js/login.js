formulario.usuario.focus();

function iniciar(e) {
    var usuario, pass;
    usuario = formulario.usuario.value;
    pass = formulario.pass.value;
    /* -- Campos vacios -- */
    if (usuario == "" && pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (usuario == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (pass == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("usuario").style.border = "0";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (usuario.length > 50) {
        document.getElementById("errors").innerHTML = "Seguro que es tu usuario?, en el registro no se <br>permitian más de 50 caracteres";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        document.getElementById("pass").style.border = "0";
        formulario.usuario.value = "";
        formulario.usuario.focus();
        e.preventDefault();
        return 0;
    }
    if (usuario.length > 50) {
        document.getElementById("errors").innerHTML = "Seguro que es tu contraseña?, en el registro no se <br>permitian más de 50 caracteres";
        document.getElementById("usuario").style.border = "0";
        document.getElementById("pass").style.border = "1px double var(--rojo-error)";
        formulario.pass.value = "";
        formulario.pass.focus();
        e.preventDefault();
        return 0;
    }
}

function showPassword(){
    var password = document.getElementById("pass");
    if (password.type == "password") {
        document.getElementById("mostrar").style.color = "var(--verde-correcto)";
        password.type = "text";
    } else {
        document.getElementById("mostrar").style.color = "var(--gris-luminoso)";
        password.type = "password";
    }
}