
/*-- Quitamos el boton de intro para que no se envie el formulario por error --*/
window.addEventListener("keypress", function(event){
    if (event.keyCode == 13){
        event.preventDefault();
    }
}, false);

formulario.dni.focus();

function registrarse(e) {
    var dni, nombre, apellidos, direccion, username;
    dni = formulario.dni.value;
    nombre = formulario.nombre.value;
    apellidos = formulario.apellidos.value;
    direccion = formulario.direccion.value;
    username = formulario.usuario.value;
    expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
    /* -- Campos vacios -- */
    if (dni == "" && nombre == "" && apellidos == "" && direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (nombre == "" && apellidos == "" && direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (apellidos == "" && direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (direccion == "" && username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (username == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "1px double var(--rojo-error)";
        e.preventDefault();
        return 0;
    }
    if (direccion == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "1px double var(--rojo-error)";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (apellidos == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (nombre == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
    if (dni == "") {
        document.getElementById("errors").innerHTML = "Los campos con * son obligatorios.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }

    /* -- Verificaciones -- */
        /* -- DNI -- */
    if (expresion_regular_dni.test(dni) == true) {
      numero = dni.substr(0 , dni.length - 1);
      letr = dni.substr(dni.length - 1, 1);
      numero = numero % 23;
      letra = 'TRWAGMYFPDXBNJZSQVHLCKET';
      letra = letra.substring(numero, numero + 1);
      if (letra != letr.toUpperCase()) {
        document.getElementById("errors").innerHTML = "La letra del DNI es incorrecta.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
     }
    } else {
        document.getElementById("errors").innerHTML = "Formato del DNI erróneo.";
        document.getElementById("dni").style.border = "1px double var(--rojo-error)";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        e.preventDefault();
        return 0;
    }
        /* -- Nombre -- */
    if (nombre.length > 50) {
        document.getElementById("errors").innerHTML = "Tu nombre? que eres. <br>Bueno debe de ser menor que 50 caracteres ponte un alias o algo.";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "1px double var(--rojo-error)";
        document.getElementById("apellidos").style.border = "0";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        formulario.nombre.focus();
        e.preventDefault();
        return 0;
    }
        /* -- Apellidos -- */
    if (apellidos.length > 50) {
        document.getElementById("errors").innerHTML = "Tus apellidos? superaste mis espectativas. <br>Bueno debe de ser menor que 50 caracteres haz un acronimo y seguro cabe..";
        document.getElementById("dni").style.border = "0";
        document.getElementById("nombre").style.border = "0";
        document.getElementById("apellidos").style.border = "1px double var(--rojo-error)";
        document.getElementById("direccion").style.border = "0";
        document.getElementById("usuario").style.border = "0";
        formulario.apellidos.focus();
        e.preventDefault();
        return 0;
    }

}

function sololtr(isEvento) {
    var evento = isEvento || window.event;
    var regex = new RegExp("^[a-zA-Z ]+$");
    var key = String.fromCharCode(!evento.charCode ? evento.which : evento.charCode);
    
    if (!regex.test(key)) {
      evento.preventDefault;
      return false;
    }
}