<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BJH - Anime Store</title>
    <link rel="shortcut icon"type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" href="../css/update.css">
</head>
<body>
    <?php
     /* -- Conexión a la base de datos -- */
        $link = mysqli_connect("localhost", "root","");
        mysqli_select_db($link,"prueba");
    /* -- Variables -- */
        $email = $_POST["email"];
        $usuario = $_POST["usuario"];
        $dni = $_POST["dni"];

        $result = mysqli_query($link, "SELECT * FROM cliente");
        $sql = "INSERT INTO persona VALUES ('$usuario', '$email', '$dni')";
    /* -- Registro de cliente -- */
    if ($sql) {
            $datos = mysqli_query($link, "SELECT * FROM persona WHERE username = '$usuario'");
            $comprueba = mysqli_query($link, "SELECT email FROM persona WHERE email = '$email'");
            $comprueba2 = mysqli_query($link, "SELECT username FROM persona WHERE username = '$usuario'");
            $comprueba3 = mysqli_query($link, "SELECT dni FROM persona WHERE dni = '$dni'");
            $data = mysqli_fetch_array($datos);
            $array = mysqli_fetch_array($comprueba);
            $array2 = mysqli_fetch_array($comprueba2);
            $array3 = mysqli_fetch_array($comprueba3);
    /* -- Algoritmo para prevenir un falso array -- */
        if ($array == "" || $array2 == "" || $array3 == "") {
            $texto = '0';
            $texcontra = '-1';
            $recup = '-2';
        } else {
            $prueba = count($array);
            $contra = count($array2);
            $recup = count($array3);
            $texto = strval($prueba);
            $texcontra = strval($contra);
            $recup = strval($recup);
        }   
        if ((strcmp ($texto, $texcontra) != 0) || (strcmp ($texto, $recup) != 0)) {
            echo "
                <div class='subcontainer'>
                    <div class='header'>
                        <h2>BJH</h2>
                    </div>
                    <fieldset class='exists'>
                        <div class='account'>
                            <h1>Los datos son incorrectos o no existen</h1>
                            <h4>Vuelve a intentarlo.</h4>
                            <div class='buttons'>
                                <hr>
                                <a href='/proyecto/recuperar.html'>
                                    <input type='button' class='nuevo' value='Regresar'>
                                </a>
                                <hr>
                            </div>
                        </div>
                    </fieldset>
                </div>
                ";
        }
        /*-- Le damos la bienvenida y que vaya a la app --*/
        if((strcmp ($texto, $texcontra) == 0) || (strcmp ($texto, $recup) == 0)) {
            $password = $data["password"];
            echo "
                <div class='subcontainer'>
                    <div class='header'>
                        <h2>BJH</h2>
                    </div>
                    <fieldset class='exists'>
                        <div class='account'>
                            <h1>Debe ser más cuidadoso la próxima vez</h1>
                            <p></p>
                            <h5>Su contraseña es: $password</h5>
                            <div class='buttons'>
                                <hr>
                                <a href='/proyecto/log-in.html'>
                                    <input class='nuevo' type='button' value='Iniciar sesión'>                          
                                </a>
                                <hr>
                            </div>
                        </div>
                    </fieldset>
                </div>
                ";
        }
    }
    ?>
</body>
</html>