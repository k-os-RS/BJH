<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BJH - Anime Store</title>
    <link rel="shortcut icon"type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" href="../css/update.css">
</head>
<body>
    <?php
     /* -- Conexión a la base de datos -- */
        $link = mysqli_connect("localhost", "root","");
        mysqli_select_db($link,"prueba");
    /* -- Variables -- */
        $usuario = $_POST["usuario"];
        $pass = $_POST["pass"];

        $result = mysqli_query($link, "SELECT * FROM cliente");
        $sql = "INSERT INTO persona VALUES ('$usuario','$pass')";
    /* -- Registro de cliente -- */
    if ($sql) {
            $datos = mysqli_query($link, "SELECT * FROM persona WHERE username = '$usuario'");
            $comprueba = mysqli_query($link, "SELECT password FROM persona WHERE username = '$usuario'");
            $comprueba2 = mysqli_query($link, "SELECT password FROM persona WHERE password = '$pass'");
            $data = mysqli_fetch_array($datos);
            $array = mysqli_fetch_array($comprueba);
            $array2 = mysqli_fetch_array($comprueba2);
    /* -- Algoritmo para prevenir un falso array -- */
        if ($array == "" || $array2 == "") {
            $texto = '0';
            $texcontra = '-1';
        } else {
            $prueba = count($array);
            $contra = count($array2);
            $texto = strval($prueba);
            $texcontra = strval($contra);
        }   
        if(strcmp ($texto, $texcontra) != 0) {
            echo "
                <div class='subcontainer'>
                    <div class='header'>
                        <h2>BJH</h2>
                    </div>
                    <fieldset class='exists'>
                        <div class='account'>
                            <h1>Tu contraseña es incorrecta</h1>
                            <h4>Vuelve a intentarlo.</h4>
                            <div class='buttons'>
                                <hr>
                                <a href='/proyecto/log-in.html'>
                                    <input type='button' class='nuevo' value='Regresar'>
                                </a>
                                <hr>
                            </div>
                        </div>
                    </fieldset>
                </div>
                ";
        }
        /*-- Le damos la bienvenida y que vaya a la app --*/
        else if (strcmp ($texto, $texcontra) == 0) {
            $nombre = $data["name"];
            $apellidos = $data["last_names"];
            $email = $data["email"];
            $direccion = $data["address"];
            $dni = $data["DNI"];
            echo "
                <div class='subcontainer'>
                    <div class='header'>
                        <h2>BJH</h2>
                    </div>
                    <fieldset class='exists'>
                        <div class='account'>
                            <h1>Bienvenid@ <br> $nombre $apellidos</h1>
                            <p></p>
                            <h5>DNI: $dni</h5>
                            <h5>Dirección: $direccion</h5>
                            <h5>Correo: $email</h5>
                            <div class='buttons'>
                                <hr>
                                <a href='/proyecto/modificar.html'>
                                    <input class='boton' type='button' value='Modificar datos'>
                                </a>
                                <hr>
                                <a href='/proyecto/log-in.html'>
                                    <input class='nuevo' type='button' value='Cerrar sesión'>                          
                                </a>
                                <hr>
                            </div>
                        </div>
                    </fieldset>
                </div>
                ";
        }
    }
    ?>
</body>
</html>