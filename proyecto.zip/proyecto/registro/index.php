<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BJH - Anime Store</title>
    <link rel="shortcut icon"type="image/x-icon" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" href="../css/update.css">
</head>
<body>
    <?php
     /* -- Conexión a la base de datos -- */
        $link = mysqli_connect("localhost", "root","");
        mysqli_select_db($link,"prueba");
    /* -- Variables -- */
        $email = $_POST["email"];
        $pass = $_POST["pass"];
        $dni = $_POST["dni"];
        $nombre = $_POST["nombre"];
        $apellidos = $_POST["apellidos"];
        $direccion = $_POST["direccion"];
        $usuario = $_POST["usuario"];

        $result = mysqli_query($link, "SELECT * FROM cliente");
        $sql = "INSERT INTO persona VALUES ('$dni','$nombre','$apellidos','$direccion','$email','$usuario','$pass','no')";
    /* -- Registro de cliente -- */
        if ($sql) {
            $comprueba = mysqli_query($link, "SELECT username FROM persona where username = '$usuario'");
            $comprueba2 = mysqli_query($link, "SELECT username FROM persona where email = '$email'");
            $array = mysqli_fetch_array($comprueba);
            $array2 = mysqli_fetch_array($comprueba2);   
        }
    /* -- Algoritmo para prevenir un falso array -- */
        if ($array == "") {
            $texto = '0';
        } else {
            $prueba = count($array);
            $texto = strval($prueba);
        }
    /* -- Comprobacion de usuario -- */
        if (strcmp ($texto, '0') != 0) {
            echo "
            <div class='subcontainer'>
                <div class='header'>
                    <h2>BJH</h2>
                </div>
                <fieldset class='exists'>
                    <div class='account'>
                        <h1>Tu nombre de usuario ya está en uso</h1>
                        <h4>Por favor elige uno distinto.</h4>
                        <div class='buttons'>
                            <hr>
                            <a href='/proyecto/'>
                                <input type='button' class='nuevo' value='Regresar'>
                            </a>
                            <hr>
                        </div>
                    </div>
                </fieldset>
            </div>
            ";
        }
        /* -- Guardamos los datos -- */
        else {
            echo "
            <div class='subcontainer'>
                <div class='header'>
                    <h2>BJH</h2>
                </div>
                <fieldset class='exists'>
                    <div class='account'>
                        <h1>Has sido registrado con éxito</h1>
                        <h4>Dale al botón para iniciar sesión.</h4>
                        <div class='buttons'>
                            <hr>
                            <a href='/proyecto/log-in.html'>
                                <input type='button' class='nuevo' value='Iniciar sesión'>
                            </a>
                            <hr>
                        </div>
                    </div>
                </fieldset>
            </div>
            ";
            mysqli_query($link,"INSERT INTO persona(name, last_names, email, DNI, address, username, password, employee) VALUES ('$nombre','$apellidos','$email','$dni','$direccion','$usuario','$pass','no')");    
            $id_array = mysqli_fetch_array(mysqli_query($link, "SELECT id_persona FROM persona WHERE username = '$usuario'"));
            $id = $id_array["id_persona"];
            mysqli_query($link,"INSERT INTO cliente(id_persona_aux, purchases) VALUES ('$id', 0)");
        }
    ?>
</body>
</html>